<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer classes
require 'vendor/autoload.php';

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->isSMTP();
    $mail->Host       = 'mail.mlungisinkosi.co.za';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'bookings@mlungisinkosi.co.za';
    $mail->Password   = 'Thando2005#';
    $mail->SMTPSecure = 'TLS'; // or 'ssl' if TLS is not available
    $mail->Port       = 587;   // 465 for SSL, 587 for TLS

    // Recipients
    $mail->setFrom('info@mlungisinkosi.co.za', 'Mlungisi Nkosi');

    $mail->addAddress('Malesaglen6@gmail.com', 'Glen Reise Malesa');//to

    // Content
    $mail->isHTML(true); // Set email format to HTML
    $mail->Subject = 'Test Email from PHP';
    $mail->Body    = 'This is a test email sent from PHP using Afrihost SMTP server.';

    // Send the email
    $mail->send();
    echo 'Email has been sent successfully!';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
